# coding: utf-8
import csv

def read_line(filename):
    value = ''
    c = open('line/' + filename+'.txt','rb')
    readlines = csv.reader(c)
    for line in readlines:
        value += line[0]+' '
    return value




def build_subway(**lines):
    """
    Input is build_subway(linename='station1 station2...'...)
    Ouput is a dictionary like {station:{neighbor1:line number,neighbor2:line number,...},station2:{...},...}
    """
    for key in lines.keys():
        # print key
        value = lines[key]
        lines[key] = value.split()
    stations = set()
    for key in lines.keys():
        stations.update(set(lines[key]))
    system = {}
    for station in stations:
        next_station = {}
        for key in lines:
            if station in lines[key]:
                line = lines[key]
                idx = line.index(station)
                if idx == 0:
                    if next_station.has_key(line[1]): 
                        temp =  next_station[line[1]]
                        temp.append(key)
                        next_station[line[1]] = temp
                    else:
                         next_station[line[1]] = [key]
                elif idx == len(line)-1:
                    if next_station.has_key(line[idx-1]): 
                        temp =  next_station[line[idx-1]]
                        temp.append(key)
                        next_station[line[idx-1]] = temp
                    else:
                         next_station[line[idx-1]] = [key]
                else:
                    if next_station.has_key(line[idx-1]): 
                        temp =  next_station[line[idx-1]]
                        temp.append(key)
                        next_station[line[idx-1]] = temp
                    else:
                         next_station[line[idx-1]] = [key]
                    if next_station.has_key(line[idx+1]): 
                        temp =  next_station[line[idx+1]]
                        temp.append(key)
                        next_station[line[idx+1]] = temp
                    else:
                         next_station[line[idx+1]] = [key]
        system[station] = next_station
    return system
def update_subway(shanghaiSubway):
    """
    due to line2 and line10 are circle lines.
    the shanghaiSubway need to update
    """
    shanghaiSubway['宜山路']['上海体育馆'] = ['line04']
    shanghaiSubway['上海体育馆']['宜山路'] = ['line04']
    return shanghaiSubway

sh_subway = build_subway(
    line1 = read_line('1'),
    line2 = read_line('2'),
    line4 = read_line('4'),
    line3 = read_line('3'),

    line5 = read_line('5'),
    line6 = read_line('6'),
    line7 = read_line('7'),
    line8 = read_line('8'),
    line9 = read_line('9'),
    line10zhi = read_line('10zhi'),
    line10 = read_line('10'),
    line11zhi = read_line('11zhi'),
    line11 = read_line('11'),
    line12 = read_line('12'),
    line13 = read_line('13'),
    line16 = read_line('16')
)
sh_subway = update_subway(sh_subway)

def cout(textList):
    for x in textList:
        print x,
    print ''



changePunishment = 2

def path_search(start, goal):
    """Find the shortest path from start state to a state
    with min change times such that is_goal(state) is true."""
    if start == goal:
        return [start]
    explored = {}
    explored[start] = 2
    queue = [ [start, ('', 0)] ]
    bestPath = [start, ('', 1110)]
    bestPathList = []
    while queue:
        queue.sort(key=lambda path:path[-1][-1])
        path = queue.pop(0)
        s = path[-2]
        # print len(queue)
        cout(path)

        if s == goal:
            bestPath = path
            # print 'Find one best path ↑'
            bestPathList.append(bestPath)
        else:
            if path[-1][-1] > bestPath[-1][-1]:
                return bestPathList

            linenum, changetimes = path[-1]
     
            for state, actions in sh_subway[s].items():
                for action in actions:
                    linechange = changetimes + 1
                    if linenum != action:
                        linechange += changePunishment
                    path2 = path[:-1] + [action, state, (action, linechange)]

                    if len(path2)>6:
                        if (path2[-2] == '上海赛车场' and path2[-4]=='嘉定新城' and path2[-6]=='马陆') or (path2[-6] == '上海赛车场' and path2[-4]=='嘉定新城' and path2[-2]=='马陆') or (path2[-2] == '龙柏新村' and path2[-4]=='龙溪路' and path2[-6]=='水城路') or (path2[-6] == '龙柏新村' and path2[-4]=='龙溪路' and path2[-2]=='水城路'):
                            linechange -= changePunishment
                            path2 = path[:-1] + [action, state, (action, linechange)]

                    
                        # cout(path2)

                    if path2.count(state)<=1:

                        if state not in explored:
                            explored[state] = linechange
                            queue.append(path2)
                        # elif linechange <= explored[state]: #正常情况
                        #     explored[state] = linechange
                        #     queue.append(path2)
                        elif linechange <= explored[state]+changePunishment: # 考虑马上到终点
                            # for next, lineNo in sh_subway[state].items():
                            #     if next == goal:
                            #         explored[state] = linechange
                            #         queue.append(path2)
                            #         pass

                            # if path2.count(state)<=1:
                            #     pass
                            explored[state] = linechange
                            queue.append(path2)
    return []




start = '航中路'
end = '杨高北路'

start,end = end,start


changePunishment = 3

pathList = path_search(start,end)

print '换乘因子: %d , 从 %s 到 %s , 共 %d 种方案:'%(changePunishment,start,end,len(pathList))
for pathPositive in pathList:
    # cout(pathPositive)   # pass

    for x in pathPositive[::1]:
        print x,
    print ''
    if len(pathPositive) > 1:
        print '共',len(pathPositive)/2-1,'站，换乘',(pathPositive[-1][-1]-len(pathPositive)/2-1)/changePunishment,'次，代价',pathPositive[-1][-1]-changePunishment+2
